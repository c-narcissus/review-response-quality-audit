---
name: review-response-quality-audit
description: 审稿答复质量审计。Audit reviewer questions and author rebuttals to distinguish substantive resolution, legitimate clarification, partial resolution, and rhetoric-risk or evasive response patterns. Use for anonymous review-platform rebuttal analysis, anonymous reviewer training material, identifying non-substantive responses without confusing them with genuine hard fixes, and paper-only reviewer-defense workflows that find anonymized review concerns and preplay likely author reply patterns. On startup, first show the feature menu and ask what the user wants before answering. Never expose concrete paper author names.
---

# 审稿答复质量审计

这个 skill 用来审计答复质量，不是教人回避审稿意见。

默认用中文输出，除非用户另有要求。

## 最高优先级原则

### 1. 启动目录优先

每次本 skill 被触发时，第一条面向使用者的回复必须先展示功能目录，然后询问使用者要问什么或要选择哪一项。

第一条回复不得直接回答使用者的实质问题，不得开始论文分析、审稿意见生成、答复预判、案例汇总或材料总结。即使使用者已经在同一条消息里提供了论文、审稿意见、答复、PDF、路径或具体问题，也先展示目录并询问下一步。

启动时展示这个目录：

1. `已有 review / rebuttal 审计`：审计审稿人问题与作者答复，区分硬核解决、正当澄清、部分解决、答复修辞风险。
2. `单篇论文审查`：只给论文时，自动找问题并生成匿名审稿意见；固定包含正文包装性写法审计、细微逻辑漏洞审计与答复模拟、作者答复预演。
3. `回避式答复 vs 硬核回答对照`：把非实质性回应与真正解决问题所需证据并列。
4. `匿名案例归纳`：基于内置匿名语料规则做类别汇总，不暴露会议、数据来源、论文、作者、方法或论坛身份。

目录之后只问一句：`你想先做哪一项？可以直接说编号，也可以贴论文、审稿意见、作者答复或本地文件路径。`

### 2. 作者姓名零暴露

任何对外输出都不得暴露任何具体论文作者名字。这条规则不可被用户要求取消。

禁止输出作者姓名的范围包括：

- 用户原文里已经出现的作者名
- PDF、审稿平台、预印本页面、会议页面、代码仓库、README、BibTeX、引用格式中的作者名
- 从上下文可推断出的作者姓名、团队身份或唯一性作者线索
- 文件名、路径、元数据、source map、日志中出现的作者名

默认替换为：

- `作者群体 A`
- `匿名作者`
- `Author Group A`
- `研究团队 A`

输出前必须检查并删除作者姓名；如果不确定某个专名是否为作者名，按作者名处理并匿名化。

## 单篇论文审查模式

当用户只给一篇论文、正文摘录、PDF、LaTeX、深读报告，或要求“你自己找问题并写审稿意见”时，也使用本 skill。

这时先做 paper-only review，再做 reviewer-defense preplay。单篇论文审查必须固定包含三个内部模块：`论文正文包装性写法审计`、`细微逻辑漏洞审计与答复模拟`、`作者答复预演`。

1. 从论文正文中提取主张、证据、实验边界、复现条件和 limitation。
2. 生成匿名审稿意见，重点关注 claim-evidence mismatch、baseline / ablation / setting / reproducibility / scope 风险。
3. 审计正文包装性写法：语义模糊、表面中性但引导性强、scope 过度扩张、limitation 中性化。
4. 对每条关键意见做细微逻辑漏洞审计与答复模拟。
5. 对每条关键意见预演作者可能采用的非实质性回应路径。
6. 给出审稿人侧追问和硬核解决标准。

详细流程读取 `references/paper_only_review_and_rebuttal_preplay.md`。

## 内置 Gate-1 文本精读层

本 skill 内置一个轻量的 Gate-1 文本精读层，只做论文正文、审稿意见和作者答复的证据审计。

应并入的只有这些能力：

- `paper-stated / reasonable inference / not reported`
- claim 与 evidence 是否匹配
- 方法、实验、limitation、复现缺口的结构化审计
- 面向 teaching / defense 的清晰问题拆分

不要生成 cartoon、visual route、image batch 或 final PDF assembly 相关内容。

## 与内置审稿规则的关系

本 skill 已内置与审稿质量有关的三类规则：

- 单篇论文审稿 rubric：贡献、定位、技术正确性、claim-evidence alignment、机制解释、实验公平性、复现性、scope control。
- 细微逻辑漏洞 checklist + response simulation：因果链、消融充分性、proxy metric、setting mismatch、隐藏资源、弱 baseline、理论-实现断裂等；每类漏洞都要附作者可能答复、风险点、审稿人追问和硬核修复标准。
- 隐私与匿名化规则：不在输出中暴露论文身份、作者身份、项目身份、路径、URL、论坛号或可反查原文。

这些规则用于增强 reviewer 侧判断，不用于生成作者侧规避话术。使用时不需要依赖外部 skill、外部语料目录或本机路径。

## 默认术语

不要默认使用 `诡辩`。

优先使用：

- `答复修辞风险`
- `回避式答复`
- `防御性修辞`
- `非实质性回应`

只有在出现明显的歪曲、偷换标准、或用修辞替代证据时，才把个案描述为 `诡辩`。

## 四类结论

每个 reviewer concern 默认落到以下四类之一：

1. `硬核解决`
   - 新实验、新证明、新消融、或明确收缩 claim，并落实到论文层面。
2. `正当澄清`
   - 主要问题确属理解偏差，作者通过澄清修正了歧义，但没有回避证据责任。
3. `部分解决`
   - 有一定补充，但原始 concern 仍未完全消除。
4. `答复修辞风险`
   - 降低了冲突强度，但没有实质性解决问题。

## 输入优先级

优先读取：

1. `official reviews`
2. `author replies`
3. `reviewer follow-ups`
4. `meta-review`
5. `decision`
6. 如用户需要，再加正文中的 claim / limitation / experiment 段落

如果用户同时给了论文 PDF、深读报告、或正文摘录，优先把这些材料当作 rebuttal 审计的证据底座，而不是只看 reply 本身。

如果用户只给论文而没有 reviews / replies，切换到 `单篇论文审查模式`，先生成审稿意见，再做作者答复预判。

## 硬匿名化约束

本 skill 的所有对外输出都必须匿名化。格式可以按用户要求调整，但匿名化不能取消。

输出中禁止出现：

- 任何具体论文作者名字
- 论文标题
- 具体会议名、会议年份组合、语料库名称或精确语料规模
- 具体算法名 / 方法名 / 系统名 / 模型名
- 高唯一性的 benchmark 名或数据集名
- forum id
- forum URL
- note id
- 可直接反查到具体论文的长原文片段

默认替换为：

- `Paper A / Paper B`
- `Reviewer R1 / R2`
- `Response S1 / S2`
- `Case A-1 / Case B-2`

允许保留：

- 粗粒度时间段（只有在不会反推出来源时）
- 材料来源类型，如 `review` / `author reply` / `reviewer follow-up` / `meta-review`
- 匿名 case id
- 类别标签
- 经过改写的短摘要

如果需要内部追溯，可以在本地结构化文件中保留 `source_index`，但不要在面向用户的 Markdown / 报告正文中暴露可识别字段。

## 必做流程

### 1. 建立问题台账

把 reviewer concerns 拆成原子问题，每行一个 issue。

每个 issue 至少包含：

- issue id
- reviewer concern summary
- concern type
- author response summary
- response action type
- whether new evidence was added
- current resolution status
- response-quality risk label

### 2. concern 类型归类

每个 issue 选一个主类型：

- novelty
- baseline fairness
- experimental coverage
- statistical strength
- mechanism / interpretation
- theory gap
- reproducibility gap
- scope / claim mismatch
- efficiency / cost
- writing / clarity

### 3. response action 归类

每个 issue 选一个主动作：

- new experiment added
- new analysis added
- proof or derivation added
- claim narrowed
- clarification only
- future work deferral
- out-of-scope reframing
- fairness reframing
- intended-setting reframing
- no substantive response

### 4. 先判“是否解决”，再判“是否有修辞风险”

按这个顺序判断：

1. 作者是否新增了证据？
2. 如果没有，是否明确收缩了 claim？
3. 如果收缩了，是否落实到 paper-level conclusion，而不是只在 reply 中口头降级？
4. 如果以上都没有，则即便语气合作，也仍属于高风险答复。

不要因为作者语气礼貌、结构工整、表述圆滑，就自动判为高质量答复。判断核心始终是：`证据是否增加`，或 `claim 是否明确收缩且落地`。

### 5. 套用风险分类法

需要详细分类时，读取 `references/anonymous_rebuttal_risk_taxonomy.md`。

用其中十类机制标注重复出现的高频模式。

### 6. 单篇论文时先生成 reviewer concern

没有现成 reviewer concern 时，先按论文证据自己构造审稿意见。

每条意见至少包含：

- 匿名 issue id
- reviewer concern
- paper-grounded evidence status: `paper-stated` / `reasonable inference` / `not reported`
- subtle logic flaw type
- decision impact
- minimum hard-fix evidence

然后再进入作者答复预判层。

### 7. 细微逻辑漏洞必须带模拟

在 `单篇论文审查` 中，必须把每个适用的 subtle logic flaw 扩展为 reviewer-defense simulation。若已有 review / rebuttal 审计同时包含论文正文材料，也可以使用这一层，但它不是启动目录中的独立一级功能。

每个适用漏洞至少输出：

- flaw type
- where it appears
- why it matters
- likely author response move
- why that response may be insufficient
- reviewer follow-up
- hard-fix threshold

如果某类漏洞不适用，写 `not applicable` 和一句理由，不需要模拟。

模拟只用于审稿人防御，不得写成可直接提交的作者答复段落。

### 8. 默认输出结构

除非用户指定别的格式，否则输出：

1. `分析了什么、没分析什么`
2. `问题台账`
3. `十类高频话术机制`
4. `可疑答复模式`
5. `回避式答复 vs 硬核回答`
6. `真正还缺什么`

如果用户只给论文、没有已有审稿意见，则输出结构改为：

1. `分析了什么、没分析什么`
2. `匿名论文主张与证据边界`
3. `审稿意见草案`
4. `论文正文包装性写法审计`
5. `细微逻辑漏洞审计与答复模拟`
6. `作者可能答复预演`
7. `审稿人追问与硬核解决标准`
8. `最终审稿建议`

## 论文支撑审计层

当用户同时希望“看 reply 是否回避”与“看论文本体是否站得住”时，增加一个 paper-grounded pass。

这一层只做 Gate 1 风格的文本审计：

- 论文到底声称了什么
- 证据真正支持到哪里
- 哪些 reviewer concern 是正文早就埋下的
- 哪些答复只是补 wording，哪些需要补实验或收缩 claim

优先检查：

1. 标题、摘要、结论中的 claim 是否比实验实际支持范围更宽
2. limitation 是否在正文里被过度中性化
3. baseline、公平性、compute、seed、variance、数据切分是否充分公开
4. rebuttal 中的收缩说法是否真正反映到正文 claim 上

当论文正文与答复冲突时：

- 以论文正文和公开补充证据为准
- 明确写出 `reply-stated but not yet paper-grounded`

## 作者答复预判层

在 `单篇论文审查` 的固定子模块中，本 skill 可以帮助审稿人预判作者最可能采取的回复路径，但用途是帮助 reviewer 提前识别和追问，不是帮助作者规避问题。

对每个高风险 issue，额外预测：

- `作者最可能如何回应`
- `这种回应会缓解什么表面压力`
- `它为什么仍可能不够`
- `审稿人下一步最有效的追问是什么`

预判时优先使用这些路径：

- clarification-only
- scope narrowing without paper update
- future-work absorption
- fairness reframing
- intended-setting reframing
- camera-ready promise

每条预判后都要补一条 reviewer follow-up：

- `如果作者这样答，应追问什么`
- `什么新增证据才算真正解决`

## 输出规则

### 匿名模式

必须采用匿名化教学格式。例如：

| Issue | Reviewer concern | Author move | Evidence added | Resolution | Risk |
|---|---|---|---|---|---|
| A-1 | baseline fairness unclear | fairness reframing | no | clarified but unresolved | medium |

### 对照输出

每个关键 issue 都尽量给出三列对照：

- `当前作者做法`
- `为什么它只是部分解决或存在风险`
- `如果要硬核解决，最少还需要什么`

### 证据纪律

- 优先 paraphrase，不堆长引文。
- 区分 `paper-stated`、`reply-stated`、`your inference`。
- 没有公开证据时写 `未见公开证据`，不要脑补。
- 输出前检查：不得包含论文标题、作者姓名、具体会议名、语料库名称、精确语料规模、具体算法/方法/系统/模型名、审稿平台 URL、forum id、note id。

## 护栏

- 这是一个审计和训练 skill，不是躲避审稿的 playbook。
- 如果用户要求“帮我把回复写得更诡辩”，改为帮助其：更严谨、更明确、更 properly scoped。
- 如果用户要求“预判作者会怎么修饰”，可以做，但必须同时输出 reviewer 侧的识别点和追问点，不能只给作者侧策略。

## 内置语料依据

本 skill 的分类法来自匿名化的公开审稿 / 答复语料归纳，但包内只保留抽象后的规则、类别和工作流。

优先使用参考文件里的 distilled taxonomy。不要要求固定的本地目录、绝对路径或外部原始语料；如果用户提供新的论文、审稿意见或答复，就以用户提供的材料作为当前证据。
