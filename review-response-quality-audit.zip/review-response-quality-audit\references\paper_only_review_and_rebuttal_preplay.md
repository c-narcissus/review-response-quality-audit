# Paper-Only Review And Rebuttal Preplay

Use this reference when the user provides a paper or deep-reading report and asks the agent to find review problems directly, then predict how authors may respond in ways that soften, redirect, or partially avoid those concerns.

This is a reviewer-defense workflow. Do not produce ready-to-submit evasive author replies.

## Required Output

Default Chinese section names:

1. `分析了什么、没分析什么`
2. `匿名论文主张与证据边界`
3. `审稿意见草案`
4. `论文正文包装性写法审计`
5. `细微逻辑漏洞审计与答复模拟`
6. `作者可能答复预演`
7. `审稿人追问与硬核解决标准`
8. `最终审稿建议`

All sections must be anonymized. Do not include paper title, author names, conference names, corpus names, exact corpus sizes, method names, model names, system names, benchmark or dataset names with high uniqueness, repository names, URLs, local paths, forum ids, note ids, or long original text fragments.

Highest-priority anonymity rule: never expose concrete paper author names. This applies even when names appear in user-provided text, PDF metadata, review platforms, preprint pages, BibTeX, code repositories, README files, local paths, logs, or source maps. Replace with `作者群体 A`, `匿名作者`, `Author Group A`, or `研究团队 A`. If uncertain whether a name is an author name, anonymize it.

## Paper-Only Review Steps

1. Read the paper using a Gate-1-style textual pass.
2. Separate `paper-stated`, `reasonable inference`, and `not reported`.
3. Extract headline claims, actual evidence, experimental setting, limitations, baselines, ablations, compute / data / seed details, and reproducibility conditions.
4. Audit paper-body packaging language: vague semantics, neutral-looking but leading wording, scope inflation, limitation neutralization, and claim softening/hardening mismatch.
5. Generate reviewer concerns from evidence gaps rather than from rhetorical dislike.
6. Rank concerns by decision impact.
7. For each high-impact concern, run subtle logic flaw simulation and preplay likely author response patterns with reviewer follow-up questions.

## Single-Paper Review Rubric

Cover these fields unless clearly not applicable:

| Field | Reviewer question |
| --- | --- |
| Contribution summary | What is the anonymized contribution, without naming the paper or method? |
| Problem positioning | Is the problem important, and is the positioning fair? |
| Novelty | Is the novelty a real conceptual advance or an A+B increment? |
| Technical soundness | Are the method, assumptions, derivations, and implementation coherent? |
| Claim-evidence alignment | Do the experiments support the strength of the claims? |
| Mechanism explanation | Is there evidence for the proposed mechanism, not only outcome gains? |
| Experiments and baselines | Are baselines strong, fairly tuned, and current enough? |
| Dataset and metric validity | Do metrics and settings measure the actual claim? |
| Reproducibility | Are data splits, seeds, compute, prompts, hyperparameters, and code details sufficient? |
| Limitations and scope | Are limitations integrated into the claims rather than isolated as soft caveats? |
| Writing clarity | Does wording hide scope, assumptions, or failure modes? |
| Decision-impact weakness | Which concern most changes the accept/reject judgment? |

## Paper-Body Packaging Language Audit

This section is mandatory inside single-paper review.

Use this table:

| Wording pattern | Where it appears | Why it matters | Reviewer rewrite / follow-up |
| --- | --- | --- | --- |

Check for:

- broad contribution language that exceeds the evaluated setting;
- neutral limitation language that makes a current evidence gap sound optional;
- “practical / realistic / general” framing without matching real-world constraints;
- “significant / robust / superior” claims without enough statistical or setting coverage;
- passive phrasing that hides missing baselines, resource assumptions, or implementation choices;
- future-work language used for evidence needed by the current claim.

## Subtle Logic Flaw Audit With Response Simulation

Report this as a standalone table, not only inside the weakness list. Every applicable flaw must include a reviewer-defense simulation of how authors may respond and why that response may be insufficient.

Use this output table:

| Flaw type | Where it appears | Why it matters | Likely author move | Why insufficient | Reviewer follow-up | Hard-fix threshold |
| --- | --- | --- | --- | --- | --- | --- |

Common flaw-to-simulation guidance:

| Flaw type | What to check | Likely author move | Reviewer follow-up |
| --- | --- | --- | --- |
| Problem-module causality gap | A stated problem motivates a module, but evidence only shows final metric gain. | Says the full-system gain proves the module addresses the problem. | Ask whether the module directly mitigates the motivating problem under controlled conditions. |
| Ablation necessity vs sufficiency gap | Removing a component hurts, but that does not prove unique responsibility. | Points to a leave-one-out ablation as sufficient proof. | Ask for component-only, interaction, and cost-matched alternatives. |
| Proxy metric substitution gap | The metric is easier to measure than the actual claim. | Says the proxy is standard or correlated with the target claim. | Ask for metrics tied to the claim, or narrower claims. |
| Setting mismatch gap | Motivation, assumptions, method, theory, and experiments use different regimes. | Reframes the target setting after the concern is raised. | Ask authors to align the regime or reduce the scope in paper-level claims. |
| Hidden extra resource gap | Extra data, labels, compute, tuning, generated data, or auxiliary statistics are not accounted for. | Says all methods use the same protocol while omitting extra-resource accounting. | Ask for resource accounting and fair comparisons. |
| Baseline degradation gap | Baselines look weak without provenance or tuning sanity checks. | Says baselines were adapted fairly or taken from prior work. | Ask for published-result checks and comparable tuning budgets. |
| Theory-implementation gap | Theorem assumptions do not match training or evaluation. | Says theory is only intuition or supports the general trend. | Ask for a mapping from assumptions to actual implementation. |
| Scope inflation gap | Local evidence is used to support broad field-level claims. | Says wording will be clarified or scope is implicit. | Ask for claim narrowing in abstract, conclusion, and limitations. |
| Correlation-as-mechanism gap | A diagnostic correlation is presented as mechanism evidence. | Says correlation is consistent with the proposed mechanism. | Ask for intervention, controlled ablation, or causal evidence. |
| Visualization-as-evidence gap | Qualitative plots or examples carry a quantitative claim. | Adds more examples or says figures are illustrative. | Ask for quantitative support and failure cases. |
| Hyperparameter-as-mechanism gap | Thresholds, temperatures, weights, schedules, or steps drive the result. | Says hyperparameters follow common defaults or are in the supplement. | Ask for sensitivity and fair tuning. |
| Privacy-preserving language gap | A privacy claim relies on no raw data sharing. | Says privacy is not the main focus or no raw data is exchanged. | Ask for threat model and leakage tests. |
| Communication-efficiency accounting gap | Only rounds are reported, not bytes, compute, memory, or wall-clock costs. | Says communication rounds are the standard metric. | Ask for full cost accounting. |
| Rebuttal fragility gap | A likely author reply would be text-only, but the concern requires evidence. | Offers clarification, promise, or future-work language. | Ask what new evidence would resolve the concern now. |

Use `not applicable` with a short reason when a flaw type does not apply.

Do not write polished author rebuttal paragraphs. The simulation should be diagnostic and short, e.g., `可能会把该问题解释为设置差异，但这仍不能证明主结论在原 scope 下成立`.

## Author Reply Preplay

For each high-impact concern, use a diagnostic table:

| Reviewer concern | Likely author move | Why it may be insufficient | Reviewer follow-up | Hard-fix threshold |
| --- | --- | --- | --- | --- |

Allowed likely author moves:

- `clarification-only`: turns a substantive gap into a wording issue.
- `scope narrowing without paper update`: narrows the claim in reply but not in paper-level claims.
- `future-work absorption`: acknowledges the issue but moves it outside the current evidence burden.
- `fairness reframing`: argues a missing comparison is not directly comparable.
- `intended-setting reframing`: narrows the target regime after review.
- `orthogonalization`: treats a threat to the main conclusion as independent.
- `camera-ready promise`: promises a fix later without current evidence.
- `soft concession`: admits the point would strengthen the paper but avoids calling it necessary.

Do not write polished author rebuttal paragraphs. Use short paraphrased descriptions of the move, then immediately provide reviewer-side detection and follow-up.

## Hard-Fix Standards

A response should count as substantive only when it provides one or more of:

- new experiment, ablation, baseline, statistical test, proof, or failure analysis;
- explicit claim narrowing in paper-level abstract / introduction / conclusion, not only in reply;
- reproducibility artifact with enough detail to rerun the disputed result;
- full resource accounting for comparisons involving compute, data, model size, tuning, or communication;
- a direct mapping between theory assumptions and implementation / evaluation.

If none is present, classify the expected answer as `答复修辞风险` or `部分解决`, not `硬核解决`.
