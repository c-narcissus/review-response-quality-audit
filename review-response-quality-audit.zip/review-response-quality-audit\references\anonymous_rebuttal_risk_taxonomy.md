# Anonymous Rebuttal Risk Taxonomy

这个参考文件用于 `审稿答复质量审计` skill。

用途：

- 审计 reviewer question / author reply 的答复质量
- 区分真正解决与非实质性回应
- 训练识别“回避式答复”而不把正当澄清误判成问题

## 推荐命名

默认不用 `诡辩`。

优先用：

- `答复修辞风险`
- `回避式答复`
- `防御性修辞`
- `非实质性回应`

只有当出现明显的歪曲、偷换标准、用修辞替代证据时，才使用 `诡辩`。

## 语料基础

本 taxonomy 来自匿名化的公开审稿 / 答复语料归纳。包内只保留抽象后的分类、规则和判断标准，不暴露具体会议名、年份组合、语料名称、精确语料规模，也不依赖任何本机目录、绝对路径或外部原始语料。

- official reviews
- author replies
- reviewer follow-ups
- meta-reviews
- decisions

## 匿名化规则

所有案例汇总都必须匿名化。

最高优先级：任何对外输出都不得暴露具体论文作者名字。即使作者名来自用户输入、PDF 元数据、审稿平台、预印本页面、BibTeX、代码仓库、README、文件名或路径，也必须替换为 `作者群体 A`、`匿名作者`、`Author Group A` 等匿名称呼。

禁止输出：

- 论文标题
- 任何具体论文作者名字
- 具体会议名、会议年份组合、语料库名称或精确语料规模
- 具体算法名 / 方法名 / 系统名 / 模型名
- 高唯一性的 benchmark 名或数据集名
- forum id
- forum URL
- note id
- 可直接反查到具体论文的长原文片段

允许输出：

- 粗粒度时间段（只有在不会反推出来源时）
- 来源类型
- 匿名 case id
- 分类标签
- paraphrase 后的短摘要

推荐 case id：

- `ANON-CRP-001`
- `ANON-BFD-002`
- `Case A-1`

如果需要保留可追溯索引，应只放在使用者自己的受控工作材料中，并避免进入用户可读报告正文或可分发 skill 包。

## 十类高频答复修辞风险

1. `补丁承诺`
   - Signal: `we will add`, `camera-ready`, `revised manuscript`
   - 风险点：承诺未来补，但当前公开证据没补上

2. `礼貌缓冲`
   - Signal: `we appreciate`, `important concern`
   - 风险点：语气降压，但证据不变

3. `澄清重构`
   - Signal: `to clarify`, `misunderstanding`
   - 风险点：把实质缺陷重写成措辞问题

4. `future-work 吸收`
   - Signal: `interesting future direction`
   - 风险点：把当前必须解决的缺口改名为 future work

5. `范围切割`
   - Signal: `outside the scope`, `not the focus`
   - 风险点：只在 rebuttal 里缩 scope，正文 claim 不同步收缩

6. `公平性防御`
   - Signal: `fair comparison`, `not directly comparable`
   - 风险点：以公平性为由回避最强 baseline

7. `目标场景重框`
   - Signal: `intended setting`, `practical scenario`
   - 风险点：把一般性 claim 静悄悄收窄到特殊 regime

8. `正交化处理`
   - Signal: `orthogonal`, `complementary`
   - 风险点：把会影响主结论的问题说成独立问题

9. `软性承认`
   - Signal: `would strengthen`, `remains unclear`
   - 风险点：把硬缺陷软化成“可加强项”

10. `过线但留刺`
   - Signal from meta-review: `remaining limitations`, `above the bar`
   - 风险点：论文过线，但 unresolved weakness 仍然存在

## 如何区分正当澄清与高风险答复

### 正当澄清通常伴随：

- 明确收缩 claim
- 修正 theorem statement / metric definition
- 新表格 / 新消融 / 新实验
- 承认更强 claim 不成立，并同步改正文

### 高风险答复通常表现为：

- 没有新增证据
- 没有把 claim 收缩落实到 paper-level conclusion
- 依赖 framing 和语气，而不是证据
- 只在 reply 中说“our intended setting”，正文却保留宽 claim

## 为什么最好结合论文正文

只看 rebuttal 线程，容易把“会说话”误判成“解决得好”。

因此更稳的做法是同时看：

- 标题 / 摘要 / 结论中的主 claim
- 实验是否真正覆盖 reviewer 质疑点
- limitation 是否提前承认
- rebuttal 的 claim narrowing 是否同步回正文

特别适合使用包内的 Gate-1 文本精读思路：

- `paper-stated`
- `reasonable inference`
- `not reported`

这三个标签能显著降低误判。

## 审稿人用的“答复预判”

这个 skill 可以做 reviewer-side reply prediction。

目标不是猜作者怎么赢，而是提前识别他们最可能采取的缓压路径。

常见预判模板：

1. `澄清型预判`
   - 可能回复：把 concern 重写成 misunderstanding
   - reviewer 应追问：澄清后是否新增任何证据？claim 是否同步收窄？

2. `future-work 型预判`
   - 可能回复：承认重要，但转成未来工作
   - reviewer 应追问：这是不是当前主结论成立所必需的验证？

3. `scope-cut 型预判`
   - 可能回复：说该问题不在本文范围
   - reviewer 应追问：标题、摘要、结论是否也同步收缩到这个范围？

4. `fairness 型预判`
   - 可能回复：说某 baseline 不直接可比
   - reviewer 应追问：最强可比 baseline 是否已经补足？

5. `camera-ready 型预判`
   - 可能回复：承诺最终版加入
   - reviewer 应追问：当前公开材料能否支持接收判断？

## 最小硬核修复模板

发现高风险答复时，优先问：

- 最强缺失 baseline 是否补了？
- variance / seeds / compute 是否补了？
- headline claim 和 conclusion 是否同步收窄？
- 关键机制的消融是否补了？
- 复现关键细节是否当下公开，而不是承诺未来公开？
